Felipe Castro de Noronha
10737032

---

O arquivo principal do EP esta em ep1.py.

A tarefa bonus consiste nos arquivos corpus_pt.txt e ep1_pt.py.
Para executalo basta executar:

$ python3 ep1_pt.py